## Module <auto_database_backup>

#### 07.05.2022
#### Version 15.0.1.0.0
#### ADD
- Initial commit for auto_database_backup

#### 14.06.2022
#### Version 15.0.2.0.1
#### ADD
- Dropbox integration added. Backup can be stored in to dropbox.

#### 20.08.2022
#### Version 15.0.3.0.1
#### ADD
- Onedrive integration added. Backup can be stored in to onedrive.

